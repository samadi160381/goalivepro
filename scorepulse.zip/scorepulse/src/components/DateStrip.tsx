'use client';
// src/components/DateStrip.tsx

import { useApp } from '@/components/AppProviders';

export type DateKey = 'yesterday' | 'today' | 'tomorrow';

const LABELS: Record<DateKey, { en: string; fr: string; ar: string }> = {
  yesterday: { en: 'Yesterday', fr: 'Hier', ar: 'أمس' },
  today: { en: 'Today', fr: "Aujourd'hui", ar: 'اليوم' },
  tomorrow: { en: 'Tomorrow', fr: 'Demain', ar: 'غدًا' }
};

export function dateKeyToIso(key: DateKey): string {
  const d = new Date();
  if (key === 'yesterday') d.setDate(d.getDate() - 1);
  if (key === 'tomorrow') d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10);
}

export function DateStrip({ active, onChange }: { active: DateKey; onChange: (k: DateKey) => void }) {
  const { lang } = useApp();
  const keys: DateKey[] = ['yesterday', 'today', 'tomorrow'];
  return (
    <div className="date-strip">
      {keys.map((k) => (
        <button
          key={k}
          className={`date-chip ${k === active ? 'active' : ''}`}
          onClick={() => onChange(k)}
        >
          {LABELS[k][lang]}
        </button>
      ))}
    </div>
  );
}
